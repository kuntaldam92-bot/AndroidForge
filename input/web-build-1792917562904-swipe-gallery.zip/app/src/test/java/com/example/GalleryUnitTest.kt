package com.example

import android.net.Uri
import com.example.data.model.MediaItem
import com.example.data.model.PhotoDecision
import com.example.data.model.SortOrder
import com.example.data.repository.DeletionReport
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class GalleryUnitTest {

    @Test
    fun testMediaItemFormatting() {
        val uri = Uri.parse("content://media/external/images/media/101")
        val item = MediaItem(
            id = 101L,
            uri = uri,
            displayName = "vacation.jpg",
            dateAddedSeconds = 1700000000L,
            dateModifiedSeconds = 1700000100L,
            sizeBytes = 5 * 1024 * 1024L, // 5 MB
            width = 4032,
            height = 3024,
            bucketName = "Camera"
        )

        assertEquals("5.0 MB", item.formattedSize)
        assertEquals("4032 × 3024", item.formattedDimensions)
        assertEquals("Camera", item.bucketName)
    }

    @Test
    fun testMediaItemKbAndGbFormatting() {
        val uri = Uri.parse("content://media/external/images/media/102")
        val itemKb = MediaItem(
            id = 102L,
            uri = uri,
            displayName = "thumbnail.jpg",
            sizeBytes = 512 * 1024L
        )
        assertEquals("512 KB", itemKb.formattedSize)

        val itemGb = MediaItem(
            id = 103L,
            uri = uri,
            displayName = "raw_archive.png",
            sizeBytes = 2L * 1024L * 1024L * 1024L
        )
        assertTrue(itemGb.formattedSize.contains("GB"))
    }

    @Test
    fun testSortOrderEnumValues() {
        assertEquals(4, SortOrder.values().size)
        assertTrue(SortOrder.values().contains(SortOrder.DATE_DESC))
        assertTrue(SortOrder.values().contains(SortOrder.DATE_ASC))
        assertTrue(SortOrder.values().contains(SortOrder.SIZE_DESC))
        assertTrue(SortOrder.values().contains(SortOrder.SIZE_ASC))
    }

    @Test
    fun testPhotoDecisionEnumValues() {
        assertEquals(4, PhotoDecision.values().size)
        assertTrue(PhotoDecision.values().contains(PhotoDecision.KEEP))
        assertTrue(PhotoDecision.values().contains(PhotoDecision.DECLINED))
        assertTrue(PhotoDecision.values().contains(PhotoDecision.SKIPPED))
        assertTrue(PhotoDecision.values().contains(PhotoDecision.UNREVIEWED))
    }

    @Test
    fun testDeletionReportAccuracy() {
        val report = DeletionReport(
            successfullyDeletedCount = 42,
            freedBytes = 120 * 1024 * 1024L,
            failedCount = 0,
            remainingKeptCount = 80,
            totalReviewedInSession = 122
        )

        assertEquals(42, report.successfullyDeletedCount)
        assertEquals(80, report.remainingKeptCount)
        assertEquals(0, report.failedCount)
        assertEquals(122, report.totalReviewedInSession)
        assertEquals("120.0 MB", report.formattedFreedBytes)
    }
}
