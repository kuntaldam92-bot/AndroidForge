package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = IndigoPrimary,
    onPrimary = IndigoOnPrimary,
    primaryContainer = IndigoPrimaryContainer,
    onPrimaryContainer = IndigoOnPrimaryContainer,
    secondary = EmeraldKeep,
    onSecondary = EmeraldOnKeep,
    secondaryContainer = EmeraldKeepContainer,
    onSecondaryContainer = EmeraldKeep,
    tertiary = CoralDecline,
    onTertiary = CoralOnDecline,
    tertiaryContainer = CoralDeclineContainer,
    onTertiaryContainer = CoralDecline,
    background = SlateBackgroundDark,
    onBackground = SlateTextPrimaryDark,
    surface = SlateSurfaceDark,
    onSurface = SlateTextPrimaryDark,
    surfaceVariant = SlateSurfaceVariantDark,
    onSurfaceVariant = SlateTextSecondaryDark,
    outline = SlateOutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = IndigoPrimary,
    onPrimary = IndigoOnPrimary,
    primaryContainer = IndigoOnPrimaryContainer,
    onPrimaryContainer = IndigoPrimaryContainer,
    secondary = EmeraldKeepDark,
    onSecondary = EmeraldOnKeep,
    secondaryContainer = EmeraldKeepContainer,
    onSecondaryContainer = EmeraldKeepDark,
    tertiary = CoralDecline,
    onTertiary = CoralOnDecline,
    tertiaryContainer = CoralDeclineContainer,
    onTertiaryContainer = CoralDeclineDark,
    background = SlateBackgroundLight,
    onBackground = SlateTextPrimaryLight,
    surface = SlateSurfaceLight,
    onSurface = SlateTextPrimaryLight,
    surfaceVariant = SlateSurfaceVariantLight,
    onSurfaceVariant = SlateTextSecondaryLight,
    outline = SlateOutlineLight
)

@Composable
fun SwipeGalleryTheme(
    themePreference: String = "SYSTEM",
    content: @Composable () -> Unit
) {
    val darkTheme = when (themePreference) {
        "DARK" -> true
        "LIGHT" -> false
        else -> isSystemInDarkTheme()
    }

    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
