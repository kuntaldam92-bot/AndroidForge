package com.example.data.model

import android.net.Uri

enum class PhotoDecision {
    UNREVIEWED,
    KEEP,
    DECLINED,
    SKIPPED
}

enum class SortOrder {
    DATE_DESC, // Newest first
    DATE_ASC,  // Oldest first
    SIZE_DESC, // Largest first
    SIZE_ASC   // Smallest first
}

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val dateAddedSeconds: Long = 0L,
    val dateModifiedSeconds: Long = 0L,
    val sizeBytes: Long = 0L,
    val width: Int = 0,
    val height: Int = 0,
    val mimeType: String = "image/jpeg",
    val bucketName: String = "Gallery"
) {
    val formattedSize: String
        get() {
            if (sizeBytes <= 0) return "Unknown size"
            val kb = sizeBytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.1f MB", mb)
                else -> String.format("%.0f KB", kb)
            }
        }

    val formattedDimensions: String
        get() {
            return if (width > 0 && height > 0) {
                "${width} × ${height}"
            } else {
                "Photo"
            }
        }
}

data class ReviewedPhoto(
    val item: MediaItem,
    val decision: PhotoDecision,
    val reviewedAt: Long = System.currentTimeMillis()
)
