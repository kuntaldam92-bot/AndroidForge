package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.MediaItem
import com.example.ui.screens.DeletionConfirmDialog
import com.example.ui.screens.FullScreenPreviewScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StorageSummaryOverlay
import com.example.ui.screens.SummaryScreen
import com.example.ui.screens.SwipeScreen
import com.example.ui.theme.SwipeGalleryTheme
import com.example.ui.viewmodel.GalleryViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: GalleryViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            // Keep track of items currently being deleted in the system intent
            var pendingDeletionItems by remember { mutableStateOf<List<MediaItem>>(emptyList()) }

            val deleteRequestLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.StartIntentSenderForResult()
            ) { result ->
                val success = result.resultCode == Activity.RESULT_OK
                viewModel.onSystemDeletionResult(
                    success = success,
                    attemptedItems = pendingDeletionItems
                )
            }

            SwipeGalleryTheme(themePreference = uiState.userSettings.themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    when (uiState.currentScreen) {
                        Screen.ONBOARDING -> {
                            OnboardingScreen(
                                onCompleteOnboarding = { viewModel.completeOnboarding() },
                                onPermissionGranted = { viewModel.loadGallery() }
                            )
                        }

                        Screen.HOME -> {
                            HomeScreen(
                                uiState = uiState,
                                onStartSwiping = { viewModel.navigateTo(Screen.SWIPE) },
                                onContinueSession = { viewModel.navigateTo(Screen.SWIPE) },
                                onOpenSettings = { viewModel.navigateTo(Screen.SETTINGS) },
                                onOpenSummary = { viewModel.navigateTo(Screen.SUMMARY) },
                                onRefreshGallery = { viewModel.loadGallery() },
                                onPermissionGranted = { viewModel.checkPermission() },
                                onSelectBucket = { bucket -> viewModel.setSelectedBucket(bucket) },
                                onSelectSortOrder = { sort -> viewModel.setSortOrder(sort) },
                                onShowStorageSummary = { viewModel.showStorageSummary(true) }
                            )
                        }

                        Screen.SWIPE -> {
                            SwipeScreen(
                                uiState = uiState,
                                onBackToHome = { viewModel.navigateTo(Screen.HOME) },
                                onSwipeRight = { item -> viewModel.swipeRight(item) },
                                onSwipeLeft = { item -> viewModel.swipeLeft(item) },
                                onSkip = { item -> viewModel.skip(item) },
                                onUndo = { viewModel.undoLastDecision() },
                                onCardClick = { item -> viewModel.openPreview(item) },
                                onGoToSummary = { viewModel.navigateTo(Screen.SUMMARY) },
                                onReviewSkipped = { viewModel.reviewSkippedPhotos() },
                                onResetSession = { viewModel.resetSession() }
                            )
                        }

                        Screen.FULLSCREEN_PREVIEW -> {
                            uiState.previewPhoto?.let { photo ->
                                FullScreenPreviewScreen(
                                    photo = photo,
                                    onClose = { viewModel.closePreview() },
                                    onKeepPhoto = { viewModel.swipeRight(photo) },
                                    onDeclinePhoto = { viewModel.swipeLeft(photo) }
                                )
                            } ?: run {
                                viewModel.navigateTo(Screen.SWIPE)
                            }
                        }

                        Screen.SUMMARY -> {
                            SummaryScreen(
                                uiState = uiState,
                                onBackToHome = { viewModel.navigateTo(Screen.HOME) },
                                onPhotoClick = { item -> viewModel.openPreview(item) },
                                onChangeDecision = { id, decision -> viewModel.changeDecision(id, decision) },
                                onReviewSkippedPhotos = { viewModel.reviewSkippedPhotos() },
                                onOpenConfirmDeletion = { viewModel.showDeleteConfirmation(true) },
                                onDismissReport = { viewModel.dismissDeletionReport() },
                                onStartNewSession = { viewModel.startNewSession() },
                                onShowStorageSummary = { viewModel.showStorageSummary(true) }
                            )
                        }

                        Screen.SETTINGS -> {
                            SettingsScreen(
                                userSettings = uiState.userSettings,
                                hasPermission = uiState.hasPermission,
                                onBack = { viewModel.navigateTo(Screen.HOME) },
                                onSetThemeMode = { mode -> viewModel.setThemeMode(mode) },
                                onSetHapticsEnabled = { enabled -> viewModel.setHapticsEnabled(enabled) },
                                onSetSwipeSensitivity = { sensitivity -> viewModel.setSwipeSensitivity(sensitivity) },
                                onSetReducedMotion = { reduced -> viewModel.setReducedMotion(reduced) },
                                onClearAllHistory = { viewModel.clearAllHistory() }
                            )
                        }
                    }

                    // Deletion confirmation dialog
                    if (uiState.showDeleteConfirmDialog) {
                        DeletionConfirmDialog(
                            declinedPhotos = uiState.declinedPhotos,
                            isDeleting = uiState.isDeleting,
                            onConfirmDelete = { itemsToDelete ->
                                pendingDeletionItems = itemsToDelete
                                val intentSender = viewModel.prepareDeleteIntentSender(itemsToDelete)
                                if (intentSender != null) {
                                    val request = IntentSenderRequest.Builder(intentSender).build()
                                    deleteRequestLauncher.launch(request)
                                } else {
                                    viewModel.executeLegacyDeletion(itemsToDelete)
                                }
                            },
                            onDismiss = { viewModel.showDeleteConfirmation(false) }
                        )
                    }

                    // Storage reclaimed summary overlay
                    if (uiState.showStorageSummaryOverlay) {
                        StorageSummaryOverlay(
                            deletionReport = uiState.deletionReport,
                            totalReviewed = uiState.reviewedCount,
                            totalKept = uiState.keptPhotos.size,
                            totalDeclined = uiState.declinedPhotos.size,
                            userSettings = uiState.userSettings,
                            onStartNewSession = {
                                viewModel.showStorageSummary(false)
                                viewModel.startNewSession()
                            },
                            onDismiss = {
                                viewModel.showStorageSummary(false)
                            }
                        )
                    }
                }
            }
        }
    }
}
