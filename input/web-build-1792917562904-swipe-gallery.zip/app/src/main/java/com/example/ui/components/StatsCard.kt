package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberSkip
import com.example.ui.theme.CoralDecline
import com.example.ui.theme.EmeraldKeep
import com.example.ui.theme.IndigoPrimary

@Composable
fun GalleryProgressCard(
    totalCount: Int,
    reviewedCount: Int,
    keptCount: Int,
    declinedCount: Int,
    declinedBytesFormatted: String,
    modifier: Modifier = Modifier
) {
    val progress = if (totalCount > 0) (reviewedCount.toFloat() / totalCount.toFloat()).coerceIn(0f, 1f) else 0f
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "progress")

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Review Progress",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "$reviewedCount of $totalCount reviewed (${(progress * 100).toInt()}%)",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (declinedCount > 0) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CoralDecline.copy(alpha = 0.12f)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = null,
                                tint = CoralDecline,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = declinedBytesFormatted,
                                color = CoralDecline,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Multi-segment progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            ) {
                if (totalCount > 0) {
                    val keptFraction = (keptCount.toFloat() / totalCount).coerceIn(0f, 1f)
                    val declinedFraction = (declinedCount.toFloat() / totalCount).coerceIn(0f, 1f)

                    Row(modifier = Modifier.fillMaxWidth()) {
                        if (keptFraction > 0f) {
                            Box(
                                modifier = Modifier
                                    .weight(keptFraction)
                                    .height(10.dp)
                                    .background(EmeraldKeep)
                            )
                        }
                        if (declinedFraction > 0f) {
                            Box(
                                modifier = Modifier
                                    .weight(declinedFraction)
                                    .height(10.dp)
                                    .background(CoralDecline)
                            )
                        }
                        val remaining = (1f - keptFraction - declinedFraction).coerceAtLeast(0f)
                        if (remaining > 0f) {
                            Spacer(modifier = Modifier.weight(remaining))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Small badge metrics
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricPill(
                    icon = Icons.Default.PhotoLibrary,
                    label = "Total",
                    count = totalCount.toString(),
                    color = IndigoPrimary
                )
                MetricPill(
                    icon = Icons.Default.Check,
                    label = "Kept",
                    count = keptCount.toString(),
                    color = EmeraldKeep
                )
                MetricPill(
                    icon = Icons.Default.Close,
                    label = "Declined",
                    count = declinedCount.toString(),
                    color = CoralDecline
                )
            }
        }
    }
}

@Composable
fun MetricPill(
    icon: ImageVector,
    label: String,
    count: String,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        modifier = Modifier.padding(horizontal = 2.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Surface(
                shape = CircleShape,
                color = color.copy(alpha = 0.15f),
                modifier = Modifier.size(24.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = count,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = label,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
