package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PhotoDecisionDao {
    @Query("SELECT * FROM photo_decisions ORDER BY reviewedAt ASC")
    fun getAllDecisionsFlow(): Flow<List<PhotoDecisionEntity>>

    @Query("SELECT * FROM photo_decisions ORDER BY reviewedAt ASC")
    suspend fun getAllDecisions(): List<PhotoDecisionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(decision: PhotoDecisionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(decisions: List<PhotoDecisionEntity>)

    @Query("DELETE FROM photo_decisions WHERE mediaId = :mediaId")
    suspend fun deleteDecision(mediaId: Long)

    @Query("DELETE FROM photo_decisions")
    suspend fun clearAll()
}
