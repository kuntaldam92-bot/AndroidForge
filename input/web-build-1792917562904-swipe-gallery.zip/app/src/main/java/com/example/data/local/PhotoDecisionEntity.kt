package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "photo_decisions")
data class PhotoDecisionEntity(
    @PrimaryKey
    val mediaId: Long,
    val uriString: String,
    val displayName: String,
    val decision: String,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val dateAddedSeconds: Long,
    val reviewedAt: Long = System.currentTimeMillis()
)
