package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_settings")

data class UserSettings(
    val onboardingCompleted: Boolean = false,
    val themeMode: String = "SYSTEM",
    val hapticsEnabled: Boolean = true,
    val swipeSensitivity: Float = 1.0f,
    val reducedMotion: Boolean = false,
    val lifetimeDeletedCount: Int = 0,
    val lifetimeBytesReclaimed: Long = 0L,
    val lifetimeReviewedCount: Int = 0
) {
    val formattedLifetimeReclaimed: String
        get() {
            if (lifetimeBytesReclaimed <= 0) return "0 MB"
            val mb = lifetimeBytesReclaimed / (1024.0 * 1024.0)
            val gb = mb / 1024.0
            return if (gb >= 1.0) String.format("%.2f GB", gb) else String.format("%.1f MB", mb)
        }
}

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        val SWIPE_SENSITIVITY = floatPreferencesKey("swipe_sensitivity")
        val REDUCED_MOTION = booleanPreferencesKey("reduced_motion")
        val LIFETIME_DELETED_COUNT = intPreferencesKey("lifetime_deleted_count")
        val LIFETIME_BYTES_RECLAIMED = longPreferencesKey("lifetime_bytes_reclaimed")
        val LIFETIME_REVIEWED_COUNT = intPreferencesKey("lifetime_reviewed_count")
    }

    val userSettingsFlow: Flow<UserSettings> = context.dataStore.data.map { preferences ->
        UserSettings(
            onboardingCompleted = preferences[PreferencesKeys.ONBOARDING_COMPLETED] ?: false,
            themeMode = preferences[PreferencesKeys.THEME_MODE] ?: "SYSTEM",
            hapticsEnabled = preferences[PreferencesKeys.HAPTICS_ENABLED] ?: true,
            swipeSensitivity = preferences[PreferencesKeys.SWIPE_SENSITIVITY] ?: 1.0f,
            reducedMotion = preferences[PreferencesKeys.REDUCED_MOTION] ?: false,
            lifetimeDeletedCount = preferences[PreferencesKeys.LIFETIME_DELETED_COUNT] ?: 0,
            lifetimeBytesReclaimed = preferences[PreferencesKeys.LIFETIME_BYTES_RECLAIMED] ?: 0L,
            lifetimeReviewedCount = preferences[PreferencesKeys.LIFETIME_REVIEWED_COUNT] ?: 0
        )
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.ONBOARDING_COMPLETED] = completed
        }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.THEME_MODE] = mode
        }
    }

    suspend fun setHapticsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.HAPTICS_ENABLED] = enabled
        }
    }

    suspend fun setSwipeSensitivity(sensitivity: Float) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.SWIPE_SENSITIVITY] = sensitivity
        }
    }

    suspend fun setReducedMotion(reduced: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.REDUCED_MOTION] = reduced
        }
    }

    suspend fun recordCompletedDeletion(deletedCount: Int, freedBytes: Long, reviewedCount: Int) {
        context.dataStore.edit { preferences ->
            val currentDeleted = preferences[PreferencesKeys.LIFETIME_DELETED_COUNT] ?: 0
            val currentBytes = preferences[PreferencesKeys.LIFETIME_BYTES_RECLAIMED] ?: 0L
            val currentReviewed = preferences[PreferencesKeys.LIFETIME_REVIEWED_COUNT] ?: 0

            preferences[PreferencesKeys.LIFETIME_DELETED_COUNT] = currentDeleted + deletedCount
            preferences[PreferencesKeys.LIFETIME_BYTES_RECLAIMED] = currentBytes + freedBytes
            preferences[PreferencesKeys.LIFETIME_REVIEWED_COUNT] = currentReviewed + reviewedCount
        }
    }

    suspend fun clearLifetimeStats() {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.LIFETIME_DELETED_COUNT] = 0
            preferences[PreferencesKeys.LIFETIME_BYTES_RECLAIMED] = 0L
            preferences[PreferencesKeys.LIFETIME_REVIEWED_COUNT] = 0
        }
    }
}
