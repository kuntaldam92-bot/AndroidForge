package com.example.ui.components

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AmberSkip
import com.example.ui.theme.CoralDecline
import com.example.ui.theme.EmeraldKeep

@Composable
fun SwipeActionButtons(
    canUndo: Boolean,
    onUndoClick: () -> Unit,
    onDeclineClick: () -> Unit,
    onSkipClick: () -> Unit,
    onKeepClick: () -> Unit,
    hapticsEnabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val view = LocalView.current

    fun performHaptic() {
        if (hapticsEnabled) {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Red Decline (Delete) button
        ActionButton(
            icon = Icons.Default.Close,
            contentDescription = "Mark for deletion",
            buttonSize = 64.dp,
            iconSize = 32.dp,
            iconColor = CoralDecline,
            borderColor = CoralDecline.copy(alpha = 0.35f),
            backgroundColor = MaterialTheme.colorScheme.surface,
            glowColor = CoralDecline.copy(alpha = 0.18f),
            testTag = "action_decline_button",
            onClick = {
                performHaptic()
                onDeclineClick()
            }
        )

        // Undo button
        ActionButton(
            icon = Icons.AutoMirrored.Filled.Undo,
            contentDescription = "Undo last decision",
            buttonSize = 48.dp,
            iconSize = 24.dp,
            iconColor = if (canUndo) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline,
            borderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
            backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
            enabled = canUndo,
            testTag = "action_undo_button",
            onClick = {
                performHaptic()
                onUndoClick()
            }
        )

        // Skip button
        ActionButton(
            icon = Icons.Default.FastForward,
            contentDescription = "Skip photo for later",
            buttonSize = 48.dp,
            iconSize = 24.dp,
            iconColor = AmberSkip,
            borderColor = AmberSkip.copy(alpha = 0.35f),
            backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
            testTag = "action_skip_button",
            onClick = {
                performHaptic()
                onSkipClick()
            }
        )

        // Green Keep button
        ActionButton(
            icon = Icons.Default.Check,
            contentDescription = "Keep photo",
            buttonSize = 64.dp,
            iconSize = 32.dp,
            iconColor = EmeraldKeep,
            borderColor = EmeraldKeep.copy(alpha = 0.35f),
            backgroundColor = MaterialTheme.colorScheme.surface,
            glowColor = EmeraldKeep.copy(alpha = 0.18f),
            testTag = "action_keep_button",
            onClick = {
                performHaptic()
                onKeepClick()
            }
        )
    }
}

@Composable
fun ActionButton(
    icon: ImageVector,
    contentDescription: String,
    buttonSize: Dp,
    iconSize: Dp,
    iconColor: Color,
    borderColor: Color,
    backgroundColor: Color,
    glowColor: Color = Color.Transparent,
    enabled: Boolean = true,
    testTag: String = "",
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1.0f,
        animationSpec = spring(),
        label = "button_scale"
    )

    Surface(
        modifier = Modifier
            .size(buttonSize)
            .scale(scale)
            .shadow(
                elevation = if (enabled) 6.dp else 1.dp,
                shape = CircleShape,
                ambientColor = glowColor,
                spotColor = glowColor
            )
            .clip(CircleShape)
            .border(width = 1.5.dp, color = borderColor, shape = CircleShape)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .testTag(testTag),
        color = backgroundColor,
        shape = CircleShape
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(buttonSize)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = iconColor,
                modifier = Modifier.size(iconSize)
            )
        }
    }
}
