package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MediaItem
import com.example.ui.components.SwipeActionButtons
import com.example.ui.components.SwipeCard
import com.example.ui.theme.EmeraldKeep
import com.example.ui.theme.IndigoPrimary
import com.example.ui.viewmodel.GalleryUiState

@Composable
fun SwipeScreen(
    uiState: GalleryUiState,
    onBackToHome: () -> Unit,
    onSwipeRight: (MediaItem) -> Unit,
    onSwipeLeft: (MediaItem) -> Unit,
    onSkip: (MediaItem) -> Unit,
    onUndo: () -> Unit,
    onCardClick: (MediaItem) -> Unit,
    onGoToSummary: () -> Unit,
    onReviewSkipped: () -> Unit,
    onResetSession: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBackToHome()
    }

    val unreviewed = uiState.unreviewedPhotos
    val totalCount = uiState.totalPhotosCount
    val reviewedCount = uiState.reviewedCount
    val progress = if (totalCount > 0) (reviewedCount.toFloat() / totalCount).coerceIn(0f, 1f) else 0f

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // Top Navigation Bar & Progress
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBackToHome,
                modifier = Modifier.testTag("swipe_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back to Home",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }

            // Progress Pill
            Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = if (totalCount > 0) "${reviewedCount + 1} of $totalCount" else "0 of 0",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            IconButton(
                onClick = onGoToSummary,
                modifier = Modifier.testTag("swipe_summary_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Assessment,
                    contentDescription = "View Summary",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        // Linear Progress bar below header
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp),
            color = IndigoPrimary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )

        // Card Stack Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            if (unreviewed.isEmpty()) {
                // Completed All Cards State
                Surface(
                    shape = RoundedCornerShape(26.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shadowElevation = 4.dp
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(28.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = EmeraldKeep.copy(alpha = 0.15f),
                            modifier = Modifier.size(72.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = EmeraldKeep,
                                    modifier = Modifier.size(40.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        Text(
                            text = "Batch Finished!",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (uiState.totalPhotosCount == 0)
                                "No photos found in your device gallery."
                            else
                                "You've reviewed all available photos. Review your decisions and confirm deletion of unwanted photos.",
                            style = MaterialTheme.typography.bodyMedium,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = onGoToSummary,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                        ) {
                            Text(
                                text = "View Summary & Clean Up",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }

                        if (uiState.skippedPhotos.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedButton(
                                onClick = onReviewSkipped,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = "Review Skipped Photos (${uiState.skippedPhotos.size})",
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = onResetSession,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Restart Session")
                            }
                        }
                    }
                }
            } else {
                // Render card stack in reverse order so top card is rendered last (on top)
                val cardsToShow = unreviewed.take(3)
                cardsToShow.reversed().forEachIndexed { reverseIndex, item ->
                    val actualIndex = cardsToShow.size - 1 - reverseIndex
                    val isTopCard = actualIndex == 0

                    SwipeCard(
                        item = item,
                        isTopCard = isTopCard,
                        cardIndex = actualIndex,
                        sensitivity = uiState.userSettings.swipeSensitivity,
                        reducedMotion = uiState.userSettings.reducedMotion,
                        onSwipeRight = { onSwipeRight(item) },
                        onSwipeLeft = { onSwipeLeft(item) },
                        onCardClick = { onCardClick(item) }
                    )
                }
            }
        }

        // Action Buttons
        if (unreviewed.isNotEmpty()) {
            val topItem = unreviewed.first()
            SwipeActionButtons(
                canUndo = uiState.decisionHistory.isNotEmpty(),
                onUndoClick = onUndo,
                onDeclineClick = { onSwipeLeft(topItem) },
                onSkipClick = { onSkip(topItem) },
                onKeepClick = { onSwipeRight(topItem) },
                hapticsEnabled = uiState.userSettings.hapticsEnabled
            )
        } else {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
