package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.MediaItem
import com.example.ui.theme.CoralDecline
import com.example.ui.theme.EmeraldKeep
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SwipeCard(
    item: MediaItem,
    isTopCard: Boolean,
    cardIndex: Int = 0,
    sensitivity: Float = 1.0f,
    reducedMotion: Boolean = false,
    onSwipeRight: () -> Unit,
    onSwipeLeft: () -> Unit,
    onCardClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Visual stack effects for peek cards
    val stackScale = if (cardIndex == 0) 1f else (1f - (cardIndex * 0.04f)).coerceAtLeast(0.88f)
    val stackOffsetY = if (cardIndex == 0) 0.dp else (cardIndex * 10).dp

    val dateFormatted = remember(item.dateAddedSeconds) {
        if (item.dateAddedSeconds > 0) {
            val sdf = SimpleDateFormat("MMM d, yyyy", Locale.getDefault())
            sdf.format(Date(item.dateAddedSeconds * 1000L))
        } else {
            "Recent"
        }
    }

    if (isTopCard) {
        SwipeableCardLayout(
            key = item.id,
            onSwipeRight = onSwipeRight,
            onSwipeLeft = onSwipeLeft,
            onCardClick = onCardClick,
            sensitivity = sensitivity,
            reducedMotion = reducedMotion,
            modifier = modifier
        ) { swipeProgress, isSwipingRight ->
            val keepAlpha = if (isSwipingRight) swipeProgress.coerceIn(0f, 1f) else 0f
            val deleteAlpha = if (!isSwipingRight) (-swipeProgress).coerceIn(0f, 1f) else 0f

            CardContent(
                item = item,
                dateFormatted = dateFormatted,
                isTopCard = true,
                keepAlpha = keepAlpha,
                deleteAlpha = deleteAlpha
            )
        }
    } else {
        Box(
            modifier = modifier
                .fillMaxSize()
                .offset(y = stackOffsetY)
                .scale(stackScale)
                .testTag("background_swipe_card")
        ) {
            CardContent(
                item = item,
                dateFormatted = dateFormatted,
                isTopCard = false,
                keepAlpha = 0f,
                deleteAlpha = 0f
            )
        }
    }
}

@Composable
private fun CardContent(
    item: MediaItem,
    dateFormatted: String,
    isTopCard: Boolean,
    keepAlpha: Float,
    deleteAlpha: Float
) {
    Card(
        modifier = Modifier
            .fillMaxSize()
            .shadow(
                elevation = if (isTopCard) 12.dp else 4.dp,
                shape = RoundedCornerShape(26.dp),
                clip = false
            ),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // 1. High resolution photo
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(item.uri)
                    .crossfade(true)
                    .build(),
                contentDescription = item.displayName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(26.dp))
            )

            // 2. Subtle directional color tint washes over photo while swiping
            if (keepAlpha > 0.02f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    EmeraldKeep.copy(alpha = 0.35f * keepAlpha)
                                )
                            )
                        )
                )
            }

            if (deleteAlpha > 0.02f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    CoralDecline.copy(alpha = 0.35f * deleteAlpha),
                                    Color.Transparent
                                )
                            )
                        )
                )
            }

            // 3. Glowing edge accent ribbon
            if (keepAlpha > 0.05f) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .width(6.dp)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(topEnd = 26.dp, bottomEnd = 26.dp))
                        .background(EmeraldKeep.copy(alpha = keepAlpha))
                )
            } else if (deleteAlpha > 0.05f) {
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .width(6.dp)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(topStart = 26.dp, bottomStart = 26.dp))
                        .background(CoralDecline.copy(alpha = deleteAlpha))
                )
            }

            // 4. Bottom gradient vignette for crisp legible metadata
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.5f),
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            )

            // 5. Photo details overlay at bottom
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomStart)
                    .padding(horizontal = 20.dp, vertical = 22.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = dateFormatted,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = item.formattedSize,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Tap to preview hint
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.25f),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Tap to preview",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = item.displayName,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1
                )

                Text(
                    text = "${item.formattedDimensions} • Tap card to preview fullscreen",
                    color = Color.White.copy(alpha = 0.75f),
                    fontSize = 12.sp
                )
            }

            // 6. Top Corner Badges (Classic Tinder style stamp)
            // KEEP Badge (Green Stamp) - Top Left
            if (keepAlpha > 0.05f) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(22.dp)
                        .rotate(-14f)
                        .border(
                            width = 3.dp,
                            color = EmeraldKeep.copy(alpha = keepAlpha),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .background(
                            color = EmeraldKeep.copy(alpha = 0.2f * keepAlpha),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = EmeraldKeep.copy(alpha = keepAlpha),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "KEEP",
                            color = EmeraldKeep.copy(alpha = keepAlpha),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }

            // DELETE Badge (Red Stamp) - Top Right
            if (deleteAlpha > 0.05f) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(22.dp)
                        .rotate(14f)
                        .border(
                            width = 3.dp,
                            color = CoralDecline.copy(alpha = deleteAlpha),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .background(
                            color = CoralDecline.copy(alpha = 0.2f * deleteAlpha),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "DELETE",
                            color = CoralDecline.copy(alpha = deleteAlpha),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            tint = CoralDecline.copy(alpha = deleteAlpha),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            // 7. Prominent Floating Center Action Badge with dynamic scaling
            if (keepAlpha > 0.08f) {
                val centerScale = 0.75f + (keepAlpha * 0.35f)
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .scale(centerScale)
                ) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color.Black.copy(alpha = 0.7f * keepAlpha),
                        border = androidx.compose.foundation.BorderStroke(
                            2.dp,
                            EmeraldKeep.copy(alpha = keepAlpha)
                        ),
                        shadowElevation = 8.dp
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 18.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = EmeraldKeep.copy(alpha = 0.9f * keepAlpha),
                                modifier = Modifier.size(54.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Keep photo",
                                        tint = Color.White,
                                        modifier = Modifier.size(32.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = if (keepAlpha >= 0.8f) "Release to Keep" else "Keep Photo",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            } else if (deleteAlpha > 0.08f) {
                val centerScale = 0.75f + (deleteAlpha * 0.35f)
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .scale(centerScale)
                ) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = Color.Black.copy(alpha = 0.7f * deleteAlpha),
                        border = androidx.compose.foundation.BorderStroke(
                            2.dp,
                            CoralDecline.copy(alpha = deleteAlpha)
                        ),
                        shadowElevation = 8.dp
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(horizontal = 24.dp, vertical = 18.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = CoralDecline.copy(alpha = 0.9f * deleteAlpha),
                                modifier = Modifier.size(54.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Delete photo",
                                        tint = Color.White,
                                        modifier = Modifier.size(30.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = if (deleteAlpha >= 0.8f) "Release to Delete" else "Mark for Deletion",
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
