package com.example.data.repository

import android.app.PendingIntent
import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Log
import com.example.data.local.PhotoDecisionDao
import com.example.data.local.PhotoDecisionEntity
import com.example.data.model.MediaItem
import com.example.data.model.PhotoDecision
import com.example.data.model.SortOrder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext

data class DeletionReport(
    val successfullyDeletedCount: Int,
    val freedBytes: Long,
    val failedCount: Int,
    val remainingKeptCount: Int,
    val totalReviewedInSession: Int = 0
) {
    val formattedFreedBytes: String
        get() {
            if (freedBytes <= 0) return "0 MB"
            val mb = freedBytes / (1024.0 * 1024.0)
            val gb = mb / 1024.0
            return if (gb >= 1.0) String.format("%.2f GB", gb) else String.format("%.1f MB", mb)
        }
}

class GalleryRepository(
    private val context: Context,
    private val decisionDao: PhotoDecisionDao
) {
    private val contentResolver: ContentResolver = context.contentResolver

    /**
     * Observes real-time changes to the Android MediaStore Images table.
     */
    fun observeGalleryChanges(): Flow<Unit> = callbackFlow {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                trySend(Unit)
            }
        }

        contentResolver.registerContentObserver(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            true,
            observer
        )

        awaitClose {
            contentResolver.unregisterContentObserver(observer)
        }
    }

    /**
     * Queries MediaStore for all local images with optional sorting and album filter.
     */
    suspend fun loadDevicePhotos(
        sortOrder: SortOrder = SortOrder.DATE_DESC,
        bucketFilter: String? = null
    ): List<MediaItem> = withContext(Dispatchers.IO) {
        val photos = mutableListOf<MediaItem>()

        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.DATE_ADDED,
            MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )

        val sortClause = when (sortOrder) {
            SortOrder.DATE_DESC -> "${MediaStore.Images.Media.DATE_ADDED} DESC"
            SortOrder.DATE_ASC -> "${MediaStore.Images.Media.DATE_ADDED} ASC"
            SortOrder.SIZE_DESC -> "${MediaStore.Images.Media.SIZE} DESC, ${MediaStore.Images.Media.DATE_ADDED} DESC"
            SortOrder.SIZE_ASC -> "${MediaStore.Images.Media.SIZE} ASC, ${MediaStore.Images.Media.DATE_ADDED} DESC"
        }

        val selection: String?
        val selectionArgs: Array<String>?

        if (!bucketFilter.isNullOrBlank() && bucketFilter != "All") {
            selection = "${MediaStore.Images.Media.BUCKET_DISPLAY_NAME} = ? AND ${MediaStore.Images.Media.SIZE} > 0"
            selectionArgs = arrayOf(bucketFilter)
        } else {
            selection = "${MediaStore.Images.Media.SIZE} > 0"
            selectionArgs = null
        }

        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                sortClause
            )?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val dateAddedColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                val dateModifiedColumn = cursor.getColumnIndex(MediaStore.Images.Media.DATE_MODIFIED)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val widthColumn = cursor.getColumnIndex(MediaStore.Images.Media.WIDTH)
                val heightColumn = cursor.getColumnIndex(MediaStore.Images.Media.HEIGHT)
                val mimeColumn = cursor.getColumnIndex(MediaStore.Images.Media.MIME_TYPE)
                val bucketColumn = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val name = cursor.getString(nameColumn) ?: "photo_$id.jpg"
                    val dateAdded = cursor.getLong(dateAddedColumn)
                    val dateModified = if (dateModifiedColumn != -1) cursor.getLong(dateModifiedColumn) else dateAdded
                    val size = cursor.getLong(sizeColumn)
                    val width = if (widthColumn != -1) cursor.getInt(widthColumn) else 0
                    val height = if (heightColumn != -1) cursor.getInt(heightColumn) else 0
                    val mimeType = if (mimeColumn != -1) cursor.getString(mimeColumn) ?: "image/jpeg" else "image/jpeg"
                    val bucketName = if (bucketColumn != -1) cursor.getString(bucketColumn) ?: "Gallery" else "Gallery"

                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )

                    photos.add(
                        MediaItem(
                            id = id,
                            uri = contentUri,
                            displayName = name,
                            dateAddedSeconds = dateAdded,
                            dateModifiedSeconds = dateModified,
                            sizeBytes = size,
                            width = width,
                            height = height,
                            mimeType = mimeType,
                            bucketName = bucketName
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e("GalleryRepository", "Error querying MediaStore", e)
        }

        photos
    }

    /**
     * Loads all distinct album/bucket names present in the device gallery.
     */
    suspend fun loadAvailableBuckets(): List<String> = withContext(Dispatchers.IO) {
        val buckets = linkedSetOf("All")
        val projection = arrayOf(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
        try {
            contentResolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                "${MediaStore.Images.Media.SIZE} > 0",
                null,
                "${MediaStore.Images.Media.BUCKET_DISPLAY_NAME} ASC"
            )?.use { cursor ->
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
                if (bucketCol != -1) {
                    while (cursor.moveToNext()) {
                        cursor.getString(bucketCol)?.let {
                            if (it.isNotBlank()) buckets.add(it)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("GalleryRepository", "Error loading albums", e)
        }
        buckets.toList()
    }

    suspend fun getSavedDecisions(): Map<Long, PhotoDecisionEntity> = withContext(Dispatchers.IO) {
        val list = decisionDao.getAllDecisions()
        list.associateBy { it.mediaId }
    }

    suspend fun saveDecision(item: MediaItem, decision: PhotoDecision) = withContext(Dispatchers.IO) {
        val entity = PhotoDecisionEntity(
            mediaId = item.id,
            uriString = item.uri.toString(),
            displayName = item.displayName,
            decision = decision.name,
            sizeBytes = item.sizeBytes,
            width = item.width,
            height = item.height,
            dateAddedSeconds = item.dateAddedSeconds,
            reviewedAt = System.currentTimeMillis()
        )
        decisionDao.insertOrUpdate(entity)
    }

    suspend fun removeDecision(mediaId: Long) = withContext(Dispatchers.IO) {
        decisionDao.deleteDecision(mediaId)
    }

    suspend fun clearAllDecisions() = withContext(Dispatchers.IO) {
        decisionDao.clearAll()
    }

    fun createDeleteIntentSender(itemsToDelete: List<MediaItem>): IntentSender? {
        val uris = itemsToDelete.map { it.uri }
        if (uris.isEmpty()) return null

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val pendingIntent: PendingIntent = MediaStore.createDeleteRequest(contentResolver, uris)
            pendingIntent.intentSender
        } else {
            null
        }
    }

    suspend fun performLegacyDeletion(
        itemsToDelete: List<MediaItem>,
        totalReviewedCount: Int = 0,
        totalKeptCount: Int = 0
    ): DeletionReport = withContext(Dispatchers.IO) {
        var deletedCount = 0
        var freedBytes = 0L
        var failedCount = 0

        for (item in itemsToDelete) {
            try {
                val rows = contentResolver.delete(item.uri, null, null)
                if (rows > 0) {
                    deletedCount++
                    freedBytes += item.sizeBytes
                    decisionDao.deleteDecision(item.id)
                } else {
                    failedCount++
                }
            } catch (e: Exception) {
                Log.e("GalleryRepository", "Failed to delete ${item.uri}", e)
                failedCount++
            }
        }

        DeletionReport(
            successfullyDeletedCount = deletedCount,
            freedBytes = freedBytes,
            failedCount = failedCount,
            remainingKeptCount = totalKeptCount,
            totalReviewedInSession = totalReviewedCount
        )
    }

    suspend fun verifyAndFinalizeSystemDeletion(
        attemptedItems: List<MediaItem>,
        totalKeptCount: Int,
        totalReviewedCount: Int = 0
    ): DeletionReport = withContext(Dispatchers.IO) {
        var successfullyDeleted = 0
        var freedBytes = 0L
        var failed = 0

        for (item in attemptedItems) {
            val stillExists = checkMediaStillExists(item.uri)
            if (!stillExists) {
                successfullyDeleted++
                freedBytes += item.sizeBytes
                decisionDao.deleteDecision(item.id)
            } else {
                failed++
            }
        }

        DeletionReport(
            successfullyDeletedCount = successfullyDeleted,
            freedBytes = freedBytes,
            failedCount = failed,
            remainingKeptCount = totalKeptCount,
            totalReviewedInSession = totalReviewedCount
        )
    }

    private fun checkMediaStillExists(uri: Uri): Boolean {
        return try {
            contentResolver.query(uri, arrayOf(MediaStore.Images.Media._ID), null, null, null)?.use { cursor ->
                cursor.moveToFirst()
            } ?: false
        } catch (e: Exception) {
            false
        }
    }
}
