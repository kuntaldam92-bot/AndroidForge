package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Indigo / Electric Violet
val IndigoPrimary = Color(0xFF6366F1)
val IndigoOnPrimary = Color(0xFFFFFFFF)
val IndigoPrimaryContainer = Color(0xFF4338CA)
val IndigoOnPrimaryContainer = Color(0xFFE0E7FF)

// Coral / Red - For Decline & Delete
val CoralDecline = Color(0xFFFF4757)
val CoralDeclineDark = Color(0xFFE02E40)
val CoralDeclineContainer = Color(0x26FF4757)
val CoralOnDecline = Color(0xFFFFFFFF)

// Emerald / Mint - For Keep & Favorites
val EmeraldKeep = Color(0xFF10B981)
val EmeraldKeepDark = Color(0xFF059669)
val EmeraldKeepContainer = Color(0x2610B981)
val EmeraldOnKeep = Color(0xFFFFFFFF)

// Amber / Gold - For Skip & Undecided
val AmberSkip = Color(0xFFF59E0B)
val AmberSkipContainer = Color(0x26F59E0B)

// Dark Theme Surfaces (Deep Obsidian Slate)
val SlateBackgroundDark = Color(0xFF090D16)
val SlateSurfaceDark = Color(0xFF131A2A)
val SlateSurfaceVariantDark = Color(0xFF1E283E)
val SlateTextPrimaryDark = Color(0xFFF8FAFC)
val SlateTextSecondaryDark = Color(0xFF94A3B8)
val SlateTextTertiaryDark = Color(0xFF64748B)
val SlateOutlineDark = Color(0xFF334155)

// Light Theme Surfaces (Warm Crisp Porcelain)
val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateSurfaceVariantLight = Color(0xFFF1F5F9)
val SlateTextPrimaryLight = Color(0xFF0F172A)
val SlateTextSecondaryLight = Color(0xFF475569)
val SlateTextTertiaryLight = Color(0xFF94A3B8)
val SlateOutlineLight = Color(0xFFE2E8F0)
