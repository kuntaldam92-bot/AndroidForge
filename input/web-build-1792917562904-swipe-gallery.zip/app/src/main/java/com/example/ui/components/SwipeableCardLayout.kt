package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.input.pointer.util.addPointerInputChange
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * A reusable swipeable card layout that uses Compose's [Modifier.pointerInput]
 * to detect horizontal swipe gestures for keeping (swipe right) or deleting (swipe left) items.
 *
 * @param key Unique key representing the item (e.g. photo id) to reset animation state when item changes.
 * @param onSwipeRight Callback invoked when the user swipes right past the threshold (Keep).
 * @param onSwipeLeft Callback invoked when the user swipes left past the threshold (Delete).
 * @param onCardClick Optional tap callback to inspect/preview the card.
 * @param sensitivity Multiplier adjusting how easily the threshold is triggered.
 * @param reducedMotion If true, skips rotation and snappy spring fling animations for accessibility.
 * @param content Slot receiving the current swipe offset fraction (-1f to 1f) and direction.
 */
@Composable
fun SwipeableCardLayout(
    key: Any,
    onSwipeRight: () -> Unit,
    onSwipeLeft: () -> Unit,
    onCardClick: (() -> Unit)? = null,
    sensitivity: Float = 1.0f,
    reducedMotion: Boolean = false,
    modifier: Modifier = Modifier,
    content: @Composable (swipeProgress: Float, isSwipingRight: Boolean) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val offsetX = remember(key) { Animatable(0f) }
    val offsetY = remember(key) { Animatable(0f) }
    val velocityTracker = remember(key) { VelocityTracker() }

    // Dynamic threshold in pixels, adjusted by user sensitivity
    val triggerThreshold = 300f / sensitivity.coerceIn(0.5f, 2.0f)

    // Calculate normalized progress between -1.0 (full left) and +1.0 (full right)
    val swipeProgress by remember {
        derivedStateOf {
            (offsetX.value / triggerThreshold).coerceIn(-1.5f, 1.5f)
        }
    }
    val isSwipingRight by remember {
        derivedStateOf { offsetX.value > 0 }
    }

    // Proportional rotation angle (e.g. up to 16 degrees tilt)
    val rotationAngle = if (reducedMotion) 0f else (offsetX.value / 25f).coerceIn(-18f, 18f)

    Box(
        modifier = modifier
            .fillMaxSize()
            .offset {
                IntOffset(
                    offsetX.value.roundToInt(),
                    offsetY.value.roundToInt()
                )
            }
            .rotate(rotationAngle)
            .then(
                if (onCardClick != null) {
                    Modifier.pointerInput(key) {
                        detectTapGestures(onTap = { onCardClick() })
                    }
                } else Modifier
            )
            .pointerInput(key) {
                detectHorizontalDragGestures(
                    onDragStart = {
                        velocityTracker.resetTracking()
                    },
                    onDragEnd = {
                        val velocityX = velocityTracker.calculateVelocity().x
                        val displacement = offsetX.value

                        coroutineScope.launch {
                            // Check if swiped past threshold OR flicked with high velocity
                            val swipedRight = displacement > triggerThreshold || velocityX > 1200f
                            val swipedLeft = displacement < -triggerThreshold || velocityX < -1200f

                            when {
                                swipedRight -> {
                                    if (!reducedMotion) {
                                        offsetX.animateTo(
                                            targetValue = 1400f,
                                            animationSpec = tween(durationMillis = 220)
                                        )
                                    }
                                    onSwipeRight()
                                }
                                swipedLeft -> {
                                    if (!reducedMotion) {
                                        offsetX.animateTo(
                                            targetValue = -1400f,
                                            animationSpec = tween(durationMillis = 220)
                                        )
                                    }
                                    onSwipeLeft()
                                }
                                else -> {
                                    // Below threshold: Snap back to center with responsive spring
                                    launch {
                                        offsetX.animateTo(
                                            targetValue = 0f,
                                            animationSpec = spring(
                                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                                stiffness = Spring.StiffnessMedium
                                            )
                                        )
                                    }
                                    launch {
                                        offsetY.animateTo(
                                            targetValue = 0f,
                                            animationSpec = spring(
                                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                                stiffness = Spring.StiffnessMedium
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    },
                    onDragCancel = {
                        coroutineScope.launch {
                            offsetX.animateTo(0f)
                            offsetY.animateTo(0f)
                        }
                    },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        velocityTracker.addPointerInputChange(change)
                        coroutineScope.launch {
                            offsetX.snapTo(offsetX.value + dragAmount)
                            // Subtle natural vertical parallax tilt while dragging horizontally
                            offsetY.snapTo(offsetY.value + (dragAmount * 0.12f))
                        }
                    }
                )
            }
            .testTag("swipeable_card_layout")
    ) {
        content(swipeProgress, isSwipingRight)
    }
}
