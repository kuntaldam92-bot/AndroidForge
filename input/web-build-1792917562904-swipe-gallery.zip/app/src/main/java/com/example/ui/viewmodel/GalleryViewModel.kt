package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.IntentSender
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.MediaItem
import com.example.data.model.PhotoDecision
import com.example.data.model.ReviewedPhoto
import com.example.data.model.SortOrder
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.preferences.UserSettings
import com.example.data.repository.DeletionReport
import com.example.data.repository.GalleryRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen {
    ONBOARDING,
    HOME,
    SWIPE,
    FULLSCREEN_PREVIEW,
    SUMMARY,
    SETTINGS
}

data class GalleryUiState(
    val currentScreen: Screen = Screen.HOME,
    val isLoading: Boolean = false,
    val hasPermission: Boolean = false,
    val permissionPermanentlyDenied: Boolean = false,
    val allPhotos: List<MediaItem> = emptyList(),
    val unreviewedPhotos: List<MediaItem> = emptyList(),
    val keptPhotos: List<MediaItem> = emptyList(),
    val declinedPhotos: List<MediaItem> = emptyList(),
    val skippedPhotos: List<MediaItem> = emptyList(),
    val decisionHistory: List<ReviewedPhoto> = emptyList(),
    val availableBuckets: List<String> = listOf("All"),
    val selectedBucket: String = "All",
    val sortOrder: SortOrder = SortOrder.DATE_DESC,
    val previewPhoto: MediaItem? = null,
    val showDeleteConfirmDialog: Boolean = false,
    val isDeleting: Boolean = false,
    val deletionReport: DeletionReport? = null,
    val showStorageSummaryOverlay: Boolean = false,
    val userSettings: UserSettings = UserSettings()
) {
    val totalPhotosCount: Int get() = allPhotos.size
    val reviewedCount: Int get() = keptPhotos.size + declinedPhotos.size + skippedPhotos.size
    val totalDeclinedBytes: Long get() = declinedPhotos.sumOf { it.sizeBytes }
    val formattedDeclinedBytes: String
        get() {
            if (totalDeclinedBytes <= 0) return "0 MB"
            val mb = totalDeclinedBytes / (1024.0 * 1024.0)
            val gb = mb / 1024.0
            return if (gb >= 1.0) String.format("%.2f GB", gb) else String.format("%.1f MB", mb)
        }
}

@OptIn(FlowPreview::class)
class GalleryViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val repository = GalleryRepository(application, db.photoDecisionDao())
    private val preferencesRepository = UserPreferencesRepository(application)

    private val _uiState = MutableStateFlow(GalleryUiState())
    val uiState: StateFlow<GalleryUiState> = _uiState.asStateFlow()

    init {
        // Observe user settings (theme, haptics, motion, etc.)
        viewModelScope.launch {
            preferencesRepository.userSettingsFlow.collect { settings ->
                _uiState.update { state ->
                    val screen = if (!settings.onboardingCompleted) Screen.ONBOARDING else state.currentScreen
                    state.copy(userSettings = settings, currentScreen = screen)
                }
            }
        }

        // Observe MediaStore changes dynamically in real time
        viewModelScope.launch {
            repository.observeGalleryChanges()
                .debounce(800) // Debounce rapid file system notifications
                .collect {
                    if (_uiState.value.hasPermission) {
                        loadGallery()
                    }
                }
        }

        checkPermission()
    }

    /**
     * Checks whether the appropriate Android version-dependent photo permission is granted.
     */
    fun checkPermission() {
        val context = getApplication<Application>()
        val hasPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_MEDIA_IMAGES
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }

        _uiState.update { it.copy(hasPermission = hasPerm) }
        if (hasPerm) {
            loadGallery()
        }
    }

    fun onPermissionResult(granted: Boolean, permanentlyDenied: Boolean = false) {
        _uiState.update {
            it.copy(
                hasPermission = granted,
                permissionPermanentlyDenied = permanentlyDenied
            )
        }
        if (granted) {
            loadGallery()
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            preferencesRepository.setOnboardingCompleted(true)
            _uiState.update { it.copy(currentScreen = Screen.HOME) }
        }
    }

    /**
     * Queries the Android MediaStore API for local device images and syncs with local decisions.
     */
    fun loadGallery() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }

            val currentBucket = _uiState.value.selectedBucket
            val currentSort = _uiState.value.sortOrder

            val photos = repository.loadDevicePhotos(
                sortOrder = currentSort,
                bucketFilter = currentBucket
            )
            val buckets = repository.loadAvailableBuckets()
            val savedDecisions = repository.getSavedDecisions()

            val kept = mutableListOf<MediaItem>()
            val declined = mutableListOf<MediaItem>()
            val skipped = mutableListOf<MediaItem>()
            val unreviewed = mutableListOf<MediaItem>()

            for (photo in photos) {
                val decisionEntity = savedDecisions[photo.id]
                if (decisionEntity != null) {
                    when (decisionEntity.decision) {
                        PhotoDecision.KEEP.name -> kept.add(photo)
                        PhotoDecision.DECLINED.name -> declined.add(photo)
                        PhotoDecision.SKIPPED.name -> skipped.add(photo)
                        else -> unreviewed.add(photo)
                    }
                } else {
                    unreviewed.add(photo)
                }
            }

            _uiState.update {
                it.copy(
                    isLoading = false,
                    allPhotos = photos,
                    unreviewedPhotos = unreviewed,
                    keptPhotos = kept,
                    declinedPhotos = declined,
                    skippedPhotos = skipped,
                    availableBuckets = buckets
                )
            }
        }
    }

    /**
     * Changes the sorting order for querying local device photos via MediaStore.
     */
    fun setSortOrder(sortOrder: SortOrder) {
        _uiState.update { it.copy(sortOrder = sortOrder) }
        loadGallery()
    }

    /**
     * Filters gallery photos by bucket/album name.
     */
    fun setSelectedBucket(bucket: String) {
        _uiState.update { it.copy(selectedBucket = bucket) }
        loadGallery()
    }

    fun swipeRight(item: MediaItem) {
        viewModelScope.launch {
            repository.saveDecision(item, PhotoDecision.KEEP)
            val newUnreviewed = _uiState.value.unreviewedPhotos.filter { it.id != item.id }
            val newKept = _uiState.value.keptPhotos + item
            val reviewed = ReviewedPhoto(item, PhotoDecision.KEEP)
            val newHistory = _uiState.value.decisionHistory + reviewed

            _uiState.update {
                it.copy(
                    unreviewedPhotos = newUnreviewed,
                    keptPhotos = newKept,
                    decisionHistory = newHistory
                )
            }

            if (newUnreviewed.isEmpty()) {
                _uiState.update { it.copy(currentScreen = Screen.SUMMARY) }
            }
        }
    }

    fun swipeLeft(item: MediaItem) {
        viewModelScope.launch {
            repository.saveDecision(item, PhotoDecision.DECLINED)
            val newUnreviewed = _uiState.value.unreviewedPhotos.filter { it.id != item.id }
            val newDeclined = _uiState.value.declinedPhotos + item
            val reviewed = ReviewedPhoto(item, PhotoDecision.DECLINED)
            val newHistory = _uiState.value.decisionHistory + reviewed

            _uiState.update {
                it.copy(
                    unreviewedPhotos = newUnreviewed,
                    declinedPhotos = newDeclined,
                    decisionHistory = newHistory
                )
            }

            if (newUnreviewed.isEmpty()) {
                _uiState.update { it.copy(currentScreen = Screen.SUMMARY) }
            }
        }
    }

    fun skip(item: MediaItem) {
        viewModelScope.launch {
            repository.saveDecision(item, PhotoDecision.SKIPPED)
            val newUnreviewed = _uiState.value.unreviewedPhotos.filter { it.id != item.id }
            val newSkipped = _uiState.value.skippedPhotos + item
            val reviewed = ReviewedPhoto(item, PhotoDecision.SKIPPED)
            val newHistory = _uiState.value.decisionHistory + reviewed

            _uiState.update {
                it.copy(
                    unreviewedPhotos = newUnreviewed,
                    skippedPhotos = newSkipped,
                    decisionHistory = newHistory
                )
            }

            if (newUnreviewed.isEmpty()) {
                _uiState.update { it.copy(currentScreen = Screen.SUMMARY) }
            }
        }
    }

    fun undoLastDecision() {
        val history = _uiState.value.decisionHistory
        if (history.isEmpty()) return

        val last = history.last()
        val remainingHistory = history.dropLast(1)

        viewModelScope.launch {
            repository.removeDecision(last.item.id)

            val newKept = _uiState.value.keptPhotos.filter { it.id != last.item.id }
            val newDeclined = _uiState.value.declinedPhotos.filter { it.id != last.item.id }
            val newSkipped = _uiState.value.skippedPhotos.filter { it.id != last.item.id }
            val newUnreviewed = listOf(last.item) + _uiState.value.unreviewedPhotos

            _uiState.update {
                it.copy(
                    unreviewedPhotos = newUnreviewed,
                    keptPhotos = newKept,
                    declinedPhotos = newDeclined,
                    skippedPhotos = newSkipped,
                    decisionHistory = remainingHistory
                )
            }
        }
    }

    fun changeDecision(mediaId: Long, newDecision: PhotoDecision) {
        val photo = _uiState.value.allPhotos.find { it.id == mediaId } ?: return
        viewModelScope.launch {
            repository.saveDecision(photo, newDecision)

            val newKept = _uiState.value.keptPhotos.filter { it.id != mediaId }.toMutableList()
            val newDeclined = _uiState.value.declinedPhotos.filter { it.id != mediaId }.toMutableList()
            val newSkipped = _uiState.value.skippedPhotos.filter { it.id != mediaId }.toMutableList()

            when (newDecision) {
                PhotoDecision.KEEP -> newKept.add(photo)
                PhotoDecision.DECLINED -> newDeclined.add(photo)
                PhotoDecision.SKIPPED -> newSkipped.add(photo)
                PhotoDecision.UNREVIEWED -> {}
            }

            _uiState.update {
                it.copy(
                    keptPhotos = newKept,
                    declinedPhotos = newDeclined,
                    skippedPhotos = newSkipped
                )
            }
        }
    }

    fun reviewSkippedPhotos() {
        val skipped = _uiState.value.skippedPhotos
        if (skipped.isEmpty()) return

        viewModelScope.launch {
            for (photo in skipped) {
                repository.removeDecision(photo.id)
            }
            _uiState.update {
                it.copy(
                    unreviewedPhotos = skipped + it.unreviewedPhotos,
                    skippedPhotos = emptyList(),
                    currentScreen = Screen.SWIPE
                )
            }
        }
    }

    fun startNewSession() {
        resetSession()
    }

    fun resetSession() {
        viewModelScope.launch {
            repository.clearAllDecisions()
            loadGallery()
            _uiState.update {
                it.copy(
                    decisionHistory = emptyList(),
                    currentScreen = Screen.SWIPE
                )
            }
        }
    }

    fun openPreview(photo: MediaItem) {
        _uiState.update { it.copy(previewPhoto = photo, currentScreen = Screen.FULLSCREEN_PREVIEW) }
    }

    fun closePreview() {
        _uiState.update { it.copy(previewPhoto = null, currentScreen = Screen.SWIPE) }
    }

    fun navigateTo(screen: Screen) {
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun showDeleteConfirmation(show: Boolean) {
        _uiState.update { it.copy(showDeleteConfirmDialog = show) }
    }

    fun prepareDeleteIntentSender(itemsToDelete: List<MediaItem>): IntentSender? {
        return repository.createDeleteIntentSender(itemsToDelete)
    }

    fun executeLegacyDeletion(itemsToDelete: List<MediaItem>) {
        viewModelScope.launch {
            _uiState.update { it.copy(isDeleting = true, showDeleteConfirmDialog = false) }
            val currentReviewed = _uiState.value.reviewedCount
            val currentKept = _uiState.value.keptPhotos.size
            val report = repository.performLegacyDeletion(
                itemsToDelete = itemsToDelete,
                totalReviewedCount = currentReviewed,
                totalKeptCount = currentKept
            )
            preferencesRepository.recordCompletedDeletion(
                deletedCount = report.successfullyDeletedCount,
                freedBytes = report.freedBytes,
                reviewedCount = report.totalReviewedInSession
            )
            loadGallery()
            _uiState.update {
                it.copy(
                    isDeleting = false,
                    deletionReport = report,
                    showStorageSummaryOverlay = true,
                    currentScreen = Screen.SUMMARY
                )
            }
        }
    }

    fun onSystemDeletionResult(success: Boolean, attemptedItems: List<MediaItem>) {
        viewModelScope.launch {
            _uiState.update { it.copy(isDeleting = true, showDeleteConfirmDialog = false) }
            if (success) {
                val currentReviewed = _uiState.value.reviewedCount
                val currentKept = _uiState.value.keptPhotos.size
                val report = repository.verifyAndFinalizeSystemDeletion(
                    attemptedItems = attemptedItems,
                    totalKeptCount = currentKept,
                    totalReviewedCount = currentReviewed
                )
                preferencesRepository.recordCompletedDeletion(
                    deletedCount = report.successfullyDeletedCount,
                    freedBytes = report.freedBytes,
                    reviewedCount = report.totalReviewedInSession
                )
                loadGallery()
                _uiState.update {
                    it.copy(
                        isDeleting = false,
                        deletionReport = report,
                        showStorageSummaryOverlay = true,
                        currentScreen = Screen.SUMMARY
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isDeleting = false,
                        deletionReport = DeletionReport(
                            successfullyDeletedCount = 0,
                            freedBytes = 0L,
                            failedCount = attemptedItems.size,
                            remainingKeptCount = it.keptPhotos.size,
                            totalReviewedInSession = it.reviewedCount
                        )
                    )
                }
            }
        }
    }

    fun showStorageSummary(show: Boolean) {
        _uiState.update { it.copy(showStorageSummaryOverlay = show) }
    }

    fun dismissDeletionReport() {
        _uiState.update { it.copy(deletionReport = null) }
    }

    // Settings actions
    fun setThemeMode(mode: String) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun setHapticsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setHapticsEnabled(enabled)
        }
    }

    fun setSwipeSensitivity(sensitivity: Float) {
        viewModelScope.launch {
            preferencesRepository.setSwipeSensitivity(sensitivity)
        }
    }

    fun setReducedMotion(reduced: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setReducedMotion(reduced)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllDecisions()
            loadGallery()
            _uiState.update {
                it.copy(
                    decisionHistory = emptyList(),
                    deletionReport = null
                )
            }
        }
    }
}
